# Third-party notices

The executable bundle includes the following packages. Their complete license texts are in `licenses/`.

- @noble/curves 1.9.1 — MIT
- @noble/hashes 1.8.0 — MIT
- @scure/base 1.2.6 — MIT
- @scure/bip32 1.7.0 — MIT
- @scure/bip39 1.6.0 — MIT
- abitype 1.2.3 — MIT
- canonicalize 5.1.0 — Apache-2.0
- isows 1.0.7 — MIT
- multiformats 14.0.5 — Apache-2.0 OR MIT
- ox 0.14.59 — MIT
- viem 2.57.14 — MIT
- ws 8.21.0 — MIT
